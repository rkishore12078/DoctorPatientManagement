﻿namespace DoctorPatientAPI.Models.DTOs
{
    public class Status
    {
        public string? DoctorState { get; set; }
    }
}
