﻿namespace DoctorPatientAPI.Models.DTOs
{
    public class UserIdsDTO
    {
        public int UserID { get; set; }
    }
}
