import { useState } from "react";
import '../../Css/PatientDoctor.css'

function PatientDoctor(props)
{
    const[doctor,setDoctor]=useState(props.path);


    return(
        <tr className="table-row">
            <td className="table-cell">{doctor.name}</td>
            <td className="table-cell">{doctor.age}</td>
            <td className="table-cell">{doctor.gender}</td>
            <td className="table-cell">{doctor.phone}</td>
            <td className="table-cell">{doctor.specialization}</td>
            <td className="table-cell">{doctor.qualification}</td>
            <td className="table-cell">{doctor.yearsOfExperience}</td>
        </tr>
    )
}

export default PatientDoctor;