import { useState,useEffect } from "react";
import NavBar from "../NavBar";
import '../../Css/PatientUpdate.css'

function PatientUpdate()
{
    const [user, setUser] = useState(
        {
            "userId": 0,
            "email": "",
            "password": "",
            "role": localStorage.getItem("role"),
            "token": ""
        }
    )

    const[patient,setPatient]=useState(
        {
            "patientId": 0,
            "name": "",
            "dateOfBirth": new Date(),
            "phone": "",
            "address": "",
            "medicalHistory": "",
            "emergencyContactName": "",
            "emergencyContactNumber": ""
        }
    );

    const [Id,setId]=useState(
        {
            "userID":0
        }
    );

    const[password,setPassword]=useState(
        {
            "userID": 0,
            "newPassword": "string"
        }
    )

    const[toggle,setToggle]=useState(true);
    const[togglePassword,setTogglePassword]=useState(true);

    useEffect(() => {
        let ignore = false;

        if (!ignore) getPatient()
        return () => { ignore = true; }
    }, []);

    var getPatient=()=>
    {
        Id.userID=Number(localStorage.getItem("userId"));
        console.log(Id.userID);
        fetch("http://localhost:5140/api/Hospital/GetPatient",
        {
            "method":"POST",
            headers:{
                "accept": "text/plain",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem('token')
            },

            "body":JSON.stringify({...Id})
        })
        .then(async (data)=>
        {
            if(data.status == 200)
            {
                setPatient(await data.json());
                // getPatient();
                console.log(patient);
            }
        })
        .catch((err)=>
        {
                console.log(err.error)
        })
    }

    var updateDetails=()=>{
        setToggle(true);
        patient.patientId= Number(localStorage.getItem("userId"));
        fetch("http://localhost:5140/api/Hospital/UpdatePatientDetails",
        {
            "method":"PUT",
            headers:{
                "accept": "text/plain",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem('token')
            },

            "body":JSON.stringify({...patient,"patient":{}})
        })
        .then(async (data)=>
        {
            if(data.status == 200)
            {
                setPatient(await data.json());
                getPatient();
                console.log(patient);
            }
        })
        .catch((err)=>
        {
                console.log(err.error)
        })
    }

    var updatePassword=()=>
    {
        password.userID=Number(localStorage.getItem("userId"));
        console.log(password.userID);
        console.log(password.newPassword);
        fetch("http://localhost:5140/api/Hospital/UpdatePassword",
        {
            "method":"PUT",
            headers:{
                "accept": "text/plain",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem('token')
            },

            "body":JSON.stringify({...password,"password":{}})
        })
        .then(async (data)=>
        {
            if(data.status == 200)
            {
                setTogglePassword(false);
            }
        })
        .catch((err)=>
        {
                console.log(err.error)
        })
    }

    return(
        <div>
            <NavBar user={user}/>
                <div className="row body">
                <div className="row rowOne">
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">Name</div>
                        { toggle ? (<div>{patient.name}</div>):
                                                            (<div>
                                                                <input value={patient.name} type="text" onChange={(event)=>{
                                                                    setPatient({...patient,"name":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">Age</div>
                        <div>{patient.age}</div>
                        </div>
                    </div>
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">Phone</div>
                        { toggle ? (<div>{patient.phone}</div>):
                                                            (<div>
                                                                <input value={patient.phone} type="tel" onChange={(event)=>{
                                                                    setPatient({...patient,"phone":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                </div>
                <div className="row rowTwo">
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">Address</div>
                        { toggle ? (<div>{patient.address}</div>):
                                                            (<div>
                                                                <input value={patient.address} type="text" onChange={(event)=>{
                                                                    setPatient({...patient,"address":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                    <div className="col-md-4 bottons individual">
                        <div className="circle">
                        <div>
                            <button disabled={toggle==false} className="btn btn-primary inner-button rowTwo" onClick={()=>{
                                setToggle(false);
                            }}>Update</button>
                        </div>
                        <div>
                            <button className="btn btn-primary inner-button rowTwo" disabled={toggle} onClick={updateDetails}>Submit</button>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">EmergencyContactName</div><br/>
                        { toggle ? (<div>{patient.emergencyContactName}</div>):
                                                            (<div>
                                                                <input value={patient.emergencyContactName} type="text" onChange={(event)=>{
                                                                    setPatient({...patient,"emergencyContactName":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                </div>
                <div className="row rowThree">
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">EmergencyContactNumber</div>
                        { toggle ? (<div>{patient.emergencyContactNumber}</div>):
                                                            (<div>
                                                                <input value={patient.emergencyContactNumber} type="tel" onChange={(event)=>{
                                                                    setPatient({...patient,"emergencyContactNumber":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                    <div className="col-md-4 individual">
                        <div className="circle">
                        <div className="titles">MedicalHistory</div>
                        { toggle ? (<div>{patient.medicalHistory}</div>):
                                                            (<div>
                                                                <input value={patient.medicalHistory} type="text" onChange={(event)=>{
                                                                    setPatient({...patient,"medicalHistory":event.target.value})
                                                                }}/>
                                                            </div>)
                        }
                        </div>
                    </div>
                    <div className="col-md-4 bottons individual">
                        <div className="circle">
                        <div>
                            <button onClick={updatePassword} className="btn btn-primary inner-button rowTwo" >Password</button>
                        </div>
                        <div>
                            {togglePassword?(<input type="password" onChange={(event)=>{
                                setPassword({...password,"newPassword":event.target.value})
                            }}/>):(<p>Password Updated...</p>)
                            }
                        </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    )
}

export default PatientUpdate;